otraSumaCuadrados=function(n){
  suma=0
    i=1
    while (i<=n){
        suma=suma+i^2
        i=i+1
    }
    return(suma)
}