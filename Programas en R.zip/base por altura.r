FsuperfRect=function(){
  cat("Longitud de la base: ");   
    base=scan(n=1,quiet=TRUE) 
    cat("Longitud de la altura: "); 
    altura=scan(n=1,quiet=TRUE) 
    S=base*altura 
    cat("Superficie del rectángulo: ",S) 
  }